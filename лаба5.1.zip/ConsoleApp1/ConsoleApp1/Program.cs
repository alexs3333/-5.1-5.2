﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Лаба 5.1
{
    class Program
    {
        static void Main(string[] args)
        {
            double x, y, min, max,f;
            x = 1;
            y = 2;
            if (y * y * y > x) max = y * y * y;
                  else  max = x;
            if (x > (x + y) * (x + y)) min = (x + y) * (x + y);
                    else  min = x;
           f = (min + 0.5) / (x * x + max);
            Console.WriteLine("f={0}", f);
            Console.ReadKey();
         
        }
    }
}