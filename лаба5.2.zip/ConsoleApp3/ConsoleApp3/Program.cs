﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Лаба 5.1
{
    class Program
    {
        static void Main(string[] args)
        {
            double x, y;
            int N;
            Console.WriteLine("Введите x");
            x = double.Parse(Console.ReadLine());
            Console.WriteLine("Введите y");
            y = double.Parse(Console.ReadLine());
            if (y > 0)
            {
                if (x > 0)
                {
                    if (y > x)
                        N = 1;
                    else N = 4;
                }
                else
                {
                    N = 3;
                }
            }
            else
            {
                if (x > 0)
                {
                    N = 4;
                }

                else

                {
                    if (y < x)
                        N = 3;
                    else N = 2;
                }
            }
       
            Console.WriteLine('\t' + " РЕЗУЛЬТАТ:");
            Console.WriteLine("N={0}",N);
            Console.ReadKey();
        }
    }
}
